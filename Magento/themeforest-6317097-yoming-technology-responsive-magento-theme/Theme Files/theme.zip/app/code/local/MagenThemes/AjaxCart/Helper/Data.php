<?php
class MagenThemes_AjaxCart_Helper_Data extends Mage_Core_Helper_Abstract
{

}