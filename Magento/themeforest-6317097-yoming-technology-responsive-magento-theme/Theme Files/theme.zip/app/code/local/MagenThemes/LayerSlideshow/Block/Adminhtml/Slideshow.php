<?php
class MagenThemes_LayerSlideshow_Block_Adminhtml_Slideshow extends Mage_Adminhtml_Block_Widget_Grid_Container
{
	public function __construct()
	{
		parent::__construct();
		
		$this->_controller = 'adminhtml_slideshow';
		$this->_blockGroup = 'layerslideshow';
		$this->_headerText = $this->__('LayerSlideshow / Slides');
	}
}