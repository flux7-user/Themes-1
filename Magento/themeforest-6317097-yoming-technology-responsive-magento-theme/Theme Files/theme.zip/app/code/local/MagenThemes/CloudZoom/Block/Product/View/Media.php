<?php
class MagenThemes_CloudZoom_Block_Product_View_Media extends Mage_Catalog_Block_Product_View_Media
{
	
	public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
     
    public function getThumbnailscroller()
    {
        if (!$this->hasData('cloudzoom')) {
            $this->setData('cloudzoom', Mage::registry('cloudzoom'));
        }
        return $this->getData('cloudzoom');
    }
}