<?php
/**
 * @category    MagenThemes
 * @package     MagenThemes_LayerSlideshow
 * @license     http://www.yestheme.com
 * @author      http://www.yestheme.com
 */

class MagenThemes_LayerSlideshow_Model_Slideshow extends Mage_Core_Model_Abstract
{
	public function _construct()
	{
		$this->_init('layerslideshow/slideshow');
	}

	
	public function getJson()
	{
		return $this->getData('json') ? $this->getData('json') : '';
	}
	public function getLayer() {
		return json_decode($this->getJson());
	}
	public function getImageUrl()
	{
		if (!$this->hasImageUrl()) {
			$this->setImageUrl(Mage::helper('layerslideshow/image')->getImageUrl($this->getImage()));
		}
		return $this->getData('image_url');
	}
}
