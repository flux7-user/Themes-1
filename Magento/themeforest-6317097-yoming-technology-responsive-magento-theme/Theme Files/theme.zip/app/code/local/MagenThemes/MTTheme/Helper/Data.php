<?php
class MagenThemes_MTTheme_Helper_Data extends Mage_Core_Helper_Abstract
{

}