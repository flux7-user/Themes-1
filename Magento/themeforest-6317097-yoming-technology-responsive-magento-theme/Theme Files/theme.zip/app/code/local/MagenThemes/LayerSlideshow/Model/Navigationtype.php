<?php class MagenThemes_LayerSlideshow_Model_Navigationtype
{
    public function toOptionArray()
    {
        return array(
            array('value'=>'none', 'label'=>Mage::helper('layerslideshow')->__('None')),
            array('value'=>'bullet', 'label'=>Mage::helper('layerslideshow')->__('Bullet')),
            array('value'=>'thumb', 'label'=>Mage::helper('layerslideshow')->__('Thumb')),
            array('value'=>'both', 'label'=>Mage::helper('layerslideshow')->__('Both'))
        );
    }

}
?>