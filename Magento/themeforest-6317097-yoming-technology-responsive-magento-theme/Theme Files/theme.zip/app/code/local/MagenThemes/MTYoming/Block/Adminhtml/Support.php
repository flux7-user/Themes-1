<?php
class MagenThemes_MTYoming_Block_Adminhtml_Support extends Mage_Adminhtml_Block_Template
{
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('mtyoming/support.phtml');
    }
}