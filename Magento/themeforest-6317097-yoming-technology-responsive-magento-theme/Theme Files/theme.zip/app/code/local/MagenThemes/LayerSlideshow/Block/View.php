<?php
/**
 * @category    MagenThemes
 * @package     MagenThemes_LayerSlideshow
 * @license     http://www.yestheme.com
 * @author      http://www.yestheme.com
 */

class MagenThemes_LayerSlideshow_Block_View extends Mage_Core_Block_Template
{
	public function getSlideshows()
	{
		$store_id = Mage::app()->getStore()->getId();
		$collection = Mage::getModel('layerslideshow/slideshow')->getCollection();
		$collection->addStoreFilter($store_id);
		$collection->addFieldToFilter('is_enabled',1);
		$collection->setOrder('sort_order','ASC');
		return $collection;
	}
	protected function _beforeToHtml()
	{
		parent::_beforeToHtml();
		
		if (!$this->getTemplate()) {
			$this->setTemplate('magenthemes/layerslideshow/default.phtml');
		}
		return $this;	
	}
}
