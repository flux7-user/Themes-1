<?php
/**
 * @category    MagenThemes
 * @package     MagenThemes_LayerSlideshow
 * @license     http://www.yestheme.com
 * @author      http://www.yestheme.com
 */

class MagenThemes_LayerSlideshow_Model_Mysql4_Slideshow extends Mage_Core_Model_Mysql4_Abstract
{
	public function _construct()
	{
		$this->_init('layerslideshow/slideshow', 'slideshow_id');
	}
	
	/**
	 * Logic performed before saving the model
	 *
	 * @param Mage_Core_Model_Abstract $object
	 * @return MagenThemes_LayerSlideshow_Model_Mysql4_Slideshow
	 */
	protected function _beforeSave(Mage_Core_Model_Abstract $object)
	{	
		return parent::_beforeSave($object);
	}
	/**
	 *
	 * @param Mage_Core_Model_Abstract $object
	 */
	protected function _afterSave(Mage_Core_Model_Abstract $object)
	{
	    $condition = $this->_getWriteAdapter()->quoteInto('slideshow_id = ?', $object->getId());
	    $this->_getWriteAdapter()->delete($this->getTable('layerslideshow/stores'), $condition);
	
	    foreach ((array)$object->getData('stores') as $store) {
	        $storeArray = array();
	        $storeArray['slideshow_id'] = $object->getId();
	        $storeArray['store_id'] = $store;
	        $this->_getWriteAdapter()->insert($this->getTable('layerslideshow/stores'), $storeArray);
	    }
	
	    return parent::_afterSave($object);
	 }
    protected function _afterLoad(Mage_Core_Model_Abstract $object)
    {
        if ($object->getId()) {
            $stores = $this->lookupStoreIds($object->getId());

            $object->setData('store_id', $stores);

        }

        return parent::_afterLoad($object);
    }
    protected function _getLoadSelect($field, $value, $object)
    {
        $select = parent::_getLoadSelect($field, $value, $object);

        if ($object->getStoreId()) {
            $storeIds = array(Mage_Core_Model_App::ADMIN_STORE_ID, (int)$object->getStoreId());
            $select->join(
                array('layerslideshow_stores' => $this->getTable('layerslideshow/stores')),
                $this->getMainTable() . '.slideshow_id = layerslideshow_stores.slideshow_id',
                array())
                ->where('is_enabled = ?', 1)
                ->where('layerslideshow_stores.store_id IN (?)', $storeIds)
                ->order('layerslideshow_stores.store_id DESC')
                ->limit(1);
        }

        return $select;
    }

    public function lookupStoreIds($pageId)
    {
        $adapter = $this->_getReadAdapter();

        $select  = $adapter->select()
            ->from($this->getTable('layerslideshow/stores'), 'store_id')
            ->where('slideshow_id = ?',(int)$pageId);

        return $adapter->fetchCol($select);
    }

    /**
     * Set store model
     *
     * @param Mage_Core_Model_Store $store
     * @return Mage_Cms_Model_Resource_Page
     */
    public function setStore($store)
    {
        $this->_store = $store;
        return $this;
    }

    /**
     * Retrieve store model
     *
     * @return Mage_Core_Model_Store
     */
    public function getStore()
    {
        return Mage::app()->getStore($this->_store);
    }

}
