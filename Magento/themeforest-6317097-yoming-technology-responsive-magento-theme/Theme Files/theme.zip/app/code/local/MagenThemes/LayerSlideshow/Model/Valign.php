<?php class MagenThemes_LayerSlideshow_Model_Valign
{
    public function toOptionArray()
    {
        return array(
            array('value'=>'top', 'label'=>Mage::helper('layerslideshow')->__('Top')),
            array('value'=>'center', 'label'=>Mage::helper('layerslideshow')->__('Center')),
            array('value'=>'bottom', 'label'=>Mage::helper('layerslideshow')->__('Bottom'))
        );
    }

}
?>