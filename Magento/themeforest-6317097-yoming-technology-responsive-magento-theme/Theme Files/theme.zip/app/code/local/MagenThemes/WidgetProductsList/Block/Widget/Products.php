<?php
class MagenThemes_WidgetProductsList_Block_Widget_Products
    extends MagenThemes_WidgetProductsList_Block_Products
    implements Mage_Widget_Block_Interface

{
    /**
     * Internal contructor
     *
     */
    protected function _construct()
    {
        parent::_construct();
    }

}