<?php
class MagenThemes_Brands_Block_Widget_Brands
    extends MagenThemes_Brands_Block_Brands
    implements Mage_Widget_Block_Interface
{
    /**
     * Internal contructor
     *
     */
    protected function _construct()
    {
        parent::_construct();
    }
}