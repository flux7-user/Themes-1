<?php class MagenThemes_LayerSlideshow_Model_Slidertype
{
    public function toOptionArray()
    {
        return array(
            array('value'=>1, 'label'=>Mage::helper('layerslideshow')->__('Fixed')),
            array('value'=>2, 'label'=>Mage::helper('layerslideshow')->__('Responsive')),
            array('value'=>3, 'label'=>Mage::helper('layerslideshow')->__('Full Width'))
        );
    }

}
?>