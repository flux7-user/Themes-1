<?php class MagenThemes_LayerSlideshow_Model_Navigationarrows
{
    public function toOptionArray()
    {
        return array(
            array('value'=>'nexttobullets', 'label'=>Mage::helper('layerslideshow')->__('With Bullets')),
            array('value'=>'solo', 'label'=>Mage::helper('layerslideshow')->__('Solo')),
            array('value'=>'none', 'label'=>Mage::helper('layerslideshow')->__('None'))
        );
    }

}
?>