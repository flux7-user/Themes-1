<?php

class MagenThemes_CloudZoom_Block_Product_View_Lightbox extends Mage_Core_Block_Template
{
}
