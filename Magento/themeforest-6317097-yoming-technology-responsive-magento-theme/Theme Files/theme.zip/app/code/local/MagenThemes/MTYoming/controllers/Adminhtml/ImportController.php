<?php
class MagenThemes_MTYoming_Adminhtml_ImportController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction() {
        $this->getResponse()->setRedirect($this->getUrl("adminhtml/system_config/edit/section/mtyoming/"));
    }
    public function blocksAction() {
        $config = Mage::helper('mtyoming')->getCfg('install/overwrite_blocks');
        Mage::getSingleton('mtyoming/import_cms')->importCmsItems('cms/block', 'blocks', $config);
        $this->getResponse()->setRedirect($this->getUrl("adminhtml/system_config/edit/section/mtyoming/"));
    }
    public function pagesAction() {
        $config = Mage::helper('mtyoming')->getCfg('install/overwrite_pages');
        Mage::getSingleton('mtyoming/import_cms')->importCmsItems('cms/page', 'pages', $config);
        $this->getResponse()->setRedirect($this->getUrl("adminhtml/system_config/edit/section/mtyoming/"));
    }
}
