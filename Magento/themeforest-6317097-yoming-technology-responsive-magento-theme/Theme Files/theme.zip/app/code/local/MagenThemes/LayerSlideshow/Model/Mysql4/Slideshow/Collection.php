<?php
/**
 * @category    MagenThemes
 * @package     MagenThemes_LayerSlideshow
 * @license     http://www.yestheme.com
 * @author      http://www.yestheme.com
 */

class MagenThemes_LayerSlideshow_Model_Mysql4_Slideshow_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
	public function _construct()
	{
		$this->_init('layerslideshow/slideshow');
	}

	/**
	 * Init collection select
	 *
	 * @return MagenThemes_LayerSlideshow_Model_Mysql4_Slideshow_Collection
	*/
	protected function _initSelect()
	{
		$this->getSelect()->from(array('main_table' => $this->getMainTable()));
		
		return $this;
	}
	public function addStoreFilter($store, $withAdmin = true)
	{
	    if ($store instanceof Mage_Core_Model_Store) {
	        $store = array($store->getId());
	    }
	
	    $this->getSelect()->join(
	        array('store_table' => $this->getTable('layerslideshow/stores')),
	        'main_table.slideshow_id = store_table.slideshow_id',
	        array()
	    )
	    ->where('store_table.store_id in (?)', ($withAdmin ? array(0, $store) : $store))
	    ->group('main_table.slideshow_id');
	
	    return $this;
	} 
}
