<?php class MagenThemes_LayerSlideshow_Model_Navigationstyle
{
    public function toOptionArray()
    {
        return array(
            array('value'=>'round', 'label'=>Mage::helper('layerslideshow')->__('Round')),
            array('value'=>'old-round', 'label'=>Mage::helper('layerslideshow')->__('Old Round')),
            array('value'=>'old-square', 'label'=>Mage::helper('layerslideshow')->__('Old Square')),
            array('value'=>'navbar-old', 'label'=>Mage::helper('layerslideshow')->__('Old Navbar'))
        );
    }

}
?>