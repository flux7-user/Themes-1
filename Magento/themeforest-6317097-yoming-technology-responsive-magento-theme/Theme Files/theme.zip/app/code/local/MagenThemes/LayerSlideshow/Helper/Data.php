<?php
/**
 * @category    MagenThemes
 * @package     MagenThemes_LayerSlideshow
 * @license     http://www.yestheme.com
 * @author      http://www.yestheme.com
 */


class MagenThemes_LayerSlideshow_Helper_Data extends Mage_Core_Helper_Abstract
{
	/**
	 * Determine whether the extension is enabled
	 *
	 * @return bool
	 */
	public function isEnabled()
	{
		return Mage::getStoreConfig('layerslideshow/settings/enabled');
	}
}
