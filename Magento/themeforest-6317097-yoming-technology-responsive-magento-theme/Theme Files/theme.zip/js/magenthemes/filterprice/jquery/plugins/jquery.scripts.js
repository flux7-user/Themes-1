$mt(function($){
	if (typeof(Magen_filterslider) == "undefined") return;
	function reload(url) {
        $.blockUI({ message:null, overlayCSS: {opacity:0.16, zIndex:99999} });
        $('.col-main').first().load(url, function(){
            $.unblockUI(); 
        });
    }
	function filterProduct(){
		var ids = $("#category").val(); 
		var filtervalue = $("#slider").slider('values');
		var baseurl= $('#filter_url').val(); 
		var remainurl='filterprice/filter/view?min='+ filtervalue[0] +'&max='+ filtervalue[1] +'&id='+ids ;
		var correctbaseurl=baseurl + remainurl; 
		if ( Magen_filterslider.params != '' ) {
            correctbaseurl += '&' + Magen_filterslider.params;
        }
		reload(correctbaseurl); 
	}
	$("#slider").slider({range:true,
		min:0,
		max:$("#max-price").val(),
		values:[Magen_filterslider.filter_min,Magen_filterslider.filter_max],
		slide: function( event, ui ) {
			$( "#filter_min" ).html(Magen_filterslider.currency+ui.values[ 0 ]);
			$( "#filter_max" ).html(Magen_filterslider.currency+ui.values[ 1 ] );
		},
		create: function(){
			filterProduct(); 
		},
		stop: function(event, ui){
			$.cookie("filterslider_min_"+Magen_filterslider.category_id, ui.values[0], { path: '/' });
            $.cookie("filterslider_max_"+Magen_filterslider.category_id, ui.values[1], { path: '/' });
			filterProduct(); 
		}
	});
});
<!-- Add wishlist product -->
(function($){
    $('.products-grid .link-wishlist, .products-list .link-wishlist').live('click', function () {
        addWishlist($(this), $(this).attr('href'),$(this).attr('data-id'));
        return false;
    });
    $('.block-wishlist a.btn-remove1').live('click', function () {
        removeWishlist($(this).attr('href'));
        return false;
    });
    function showWMessage(message){
        $('body').append('<div class="message-alert"></div>');
        $('.message-alert').html(message).append('<button></button>');
        $('.message-alert').animate({opacity:1}, 300);
        $('button').click(function () {
            $('.message-alert').animate({opacity:0}, 300);
        });
        $('.message-alert').animate({opacity: 1},'300', function () {
            setTimeout(function () {
                $('.message-alert').animate({opacity: 0},'300', function () {
                    $(this).animate({opacity:0},300, function(){ $(this).detach(); })
                });
            }, 9000)
        });
    }
    function addWishlist(e,url,id){
        url = url.replace("wishlist/index","filterprice/product");
        url += 'isAjax/1/';
        $('.block-wishlist').addClass('wisthlist-loading');
        $('.block-wishlist .block-content').css('display','none');
        $.ajax({
            url:url,
            dataType:'jsonp',
            success:function (data) {
                showWMessage(data.message);
                if (data.status != 'ERROR' && $('.block-wishlist').length) {
                    $('.block-wishlist').removeClass('wisthlist-loading');
                    $('.block-wishlist .block-content').css('display','block');
                    $('.block-wishlist').replaceWith(data.sidebar);
                }
                if(data.message!='Please Login First'){
                    $('.quick-access .links').replaceWith(data.toplink);
                }
            }
        });
        return false;
    }
    function removeWishlist(url){
        url = url.replace("wishlist/index","filterprice/product");
        url += 'isAjax/1/';
        $('.block-wishlist').addClass('wishlist-loading');
        $('.block-wishlist .block-content').css('display','none');
        $.ajax({
            url:url,
            dataType:'jsonp',
            success:function (data) {
                showWMessage(data.message);
                if (data.status != 'ERROR' && $('.block-wishlist').length) {
                    $('.block-wishlist').removeClass('wishlist-loading');
                    $('.block-wishlist .block-content').css('display','block');
                    $('.block-wishlist').replaceWith(data.sidebar);
                }
                $('.quick-access .links').replaceWith(data.toplink);
            }
        });
    }
})(jQuery);
<!-- End Add wishlist product -->

<!-- Add compare product -->
(function($){
    $('.products-grid .link-compare, .products-grid .link-compare, .products-list .link-compare, .link-compare').live('click', function () {
        addCompare($(this), $(this).attr('href'), $(this).attr('data-id'));
        return false;
    });
    $('.block-compare a.btn-remove').live('click', function () {
        if(confirm($(this).attr('data-confirm'))){
            removeCompare($(this).attr('href'));
        }
        return false;
    });
    $('.block-compare a.btn-remove-all').live('click', function () {
        if(confirm($(this).attr('data-confirm'))){
            clearCompare($(this).attr('href'));
        }
        return false;
    });
    $('.mt-maincompare a.btn-remove').live('click', function () {
        if(confirm($(this).attr('data-confirm'))){
            removeCompare($(this).attr('href'));
        }
        return false;
    });
    $('.mt-maincompare a.btn-remove-all').live('click', function () {
        if(confirm($(this).attr('data-confirm'))){
            clearCompare($(this).attr('href'));
        }
        return false;
    });

    function showCPopup(message){
        $('body').append('<div class="message-alert"></div>');
        $('.message-alert').html(message).append('<button></button>');
        $('.message-alert').animate({opacity:1}, 300);
        $('button').click(function () {
            $('.message-alert').animate({opacity:0}, 300);
        });
        $('.message-alert').animate({opacity: 1},'300', function () {
            setTimeout(function () {
                $('.message-alert').animate({opacity: 0},'300', function () {
                    $(this).animate({opacity:0},300, function(){ $(this).detach(); })
                });
            }, 9000)
        });
    }

    function addCompare(e,url,id){
        url = url.replace("catalog/product_compare/add","filterprice/product/compare");
        url += 'isAjax/1/';
        $('.block-compare').addClass('compare-loading');
        $('.block-compare .block-content').css('display','none');
        $.ajax({
            url:url,
            dataType:'jsonp',
            success:function (data) {
                showCPopup(data.message);
                if (data.status != 'ERROR' && $('.block-compare').length) {
                    $('.block-compare').removeClass('compare-loading');
                    $('.block-compare .block-content').css('display','block');
                    $('.block-compare').replaceWith(data.output);
                }
            }
        });
    }

    function removeCompare(url){
        url = url.replace("catalog/product_compare/remove","filterprice/product/rmcompare");
        url += 'isAjax/1/';
        $('.block-compare').addClass('compare-loading');
        $('.block-compare .block-content').css('display','none');
        $.ajax({
            url:url,
            dataType:'jsonp',
            success:function (data) {
                showCPopup(data.message);
                if (data.status != 'ERROR' && $('.block-compare').length) {
                    $('.block-compare').removeClass('compare-loading');
                    $('.block-compare .block-content').css('display','block');
                    $('.block-compare').replaceWith(data.output);
                }
            }
        });
    }

    function clearCompare(url){
        url = url.replace("catalog/product_compare/clear","filterprice/product/clearall");
        url += 'isAjax/1/';
        $('.block-compare').addClass('compare-loading');
        $('.block-compare .block-content').css('display','none');
        $.ajax({
            url:url,
            dataType:'jsonp',
            success:function (data) {
                if (data.status != 'ERROR' && $('.block-compare').length) {
                    showCPopup(data.message);
                    $('.block-compare').removeClass('compare-loading');
                    $('.block-compare .block-content').css('display','block');
                    $('.block-compare').replaceWith(data.output);
                }
            }
        });
    }
})(jQuery);
<!-- End Add compare product -->