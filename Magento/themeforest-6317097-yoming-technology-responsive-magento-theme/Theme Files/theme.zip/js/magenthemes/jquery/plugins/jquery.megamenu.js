(function($){
    $.fn.megamenu = function(options) {
        options = $.extend({
            animation: "show",
            mm_timeout: 0
        }, options);
        var $megamenu_object = this;
        $megamenu_object.find("li.parent").each(function(){
            var $mm_item = $(this).children('div');
            $mm_item.hide();
            $mm_item.wrapInner('<div class="mm-item-base clearfix"></div>');
            var $timer = 0;
            $(this).bind('mouseenter', function(e){
                var mm_item_obj = $(this).children('div');
                $(this).find("a:first").addClass('hover');
                clearTimeout($timer);
                $timer = setTimeout(function(){
                    switch(options.animation) {
                        case "show":
                            mm_item_obj.show().addClass("shown-sub");
                            break;
                        case "slide":
                            mm_item_obj.height("auto");
                            mm_item_obj.slideDown('fast', function(){
                                mm_item_obj.css("overflow","inherit");
                            }).addClass("shown-sub");

                            break;
                        case "fade":
                            mm_item_obj.fadeTo('fast').addClass("shown-sub");
                            break;
                    }
                }, options.mm_timeout);
            });
            $(this).bind('mouseleave', function(e){
                clearTimeout($timer);
                var mm_item_obj = $(this).children('div');
                $(this).find("a:first").removeClass('hover');
                switch(options.animation) {
                    case "show":
                        mm_item_obj.hide();
                        break;
                    case "slide":
                        mm_item_obj.hide();
                        break;
                    case "fade":
                        mm_item_obj.hide();
                        break;
                }
            });
        });
        this.show();
    };
})(jQuery);
